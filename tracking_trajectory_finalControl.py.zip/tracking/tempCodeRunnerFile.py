axs[1].scatter(y1,label= "stars", color= "red",
#             marker= "*", s=30)