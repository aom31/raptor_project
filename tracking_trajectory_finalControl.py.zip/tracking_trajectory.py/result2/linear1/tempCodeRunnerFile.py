axs[2,0].plot(cte3,'y')   #, -y2,'r'
# axs[2,0].plot(xNorth,label="ref_linear") 