with open (ref_latlng) as f:
#     ref_data = pd.read_table(f, sep=',', header=0, names=['x','y'], lineterminator='\n')
    
# ref_lng = ref_data.x
# ref_lat = ref_data.y
# with open (ref_utm ) as f:
#     ref_dataU = pd.read_table(f, sep=',', header=0, names=['x','y'], lineterminator='\n')
    
# ref_xNorth = ref_dataU.x
# ref_yEast = ref_dataU.y